@extends('layouts.app')

@section('content')

<div class="container">
<a href="/student/show" class="btn btn-primary"> Go Back </a>

    <div class="row justify-content-center">
        <div class="col-md-8">
        <div class="card">



                <div class="card-body">
        <form method="post" action="{{route('editDegree', ['id' => $student[0]->id])}}">  
        @csrf
         
          <h1> {{$student[0]->userName}} </h1>
         
                <ul>
                            <li class="list-group-item">
                                  <label for="subject" class="col-md-4 col-form-label text-md-right">English</label>
                                  <?php $flag=0 ?>
                                  @foreach($grade as $service)
                                        @if($service->id ==1)
                                           <?php $flag=1 ?>
                                            <input id="1" type="1" name="1" value="{{$service->grade}}" >
                                        @endif
                                  @endforeach
                                  @if($flag==0)
                                        <input id="1" type="1" name="1" value="0" >
                                  @endif

                            </li>
                            <li class="list-group-item">
                                  <label for="subject" class="col-md-4 col-form-label text-md-right">Math</label>
                                  <?php $flag=0 ?>
                                  @foreach($grade as $service)
                                        @if($service->id ==2)
                                             <?php $flag=1 ?>
                                            <input id="2" type="2" name="2" value="{{$service->grade}}" >
                                        @endif
                                  @endforeach
                                  @if($flag==0)
                                        <input id="2" type="2" name="2" value="0" >
                                  @endif            
                            </li>
                            <li class="list-group-item">
                                  <label for="subject" class="col-md-4 col-form-label text-md-right">History</label>
                                  <?php $flag=0 ?>
                                  @foreach($grade as $service)
                                        @if($service->id ==3)
                                            <?php $flag=1 ?>
                                            <input id="3" type="3" name="3" value="{{$service->grade}}" >
                                        @endif
                                  @endforeach
                                  @if($flag==0)
                                        <input id="3" type="3" name="3" value="0" >
                                  @endif
                            </li>
                </ul>    
                        @if(Auth::user()->typeOfUser !=3)
                         <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ _('update') }}
                                </button>
                            </div>
                        </div>
                        @endif
            </form>  
            </div>
            </div>
        </div>
    </div>
</div>
@endsection



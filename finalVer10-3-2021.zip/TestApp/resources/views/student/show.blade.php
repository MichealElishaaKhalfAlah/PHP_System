@extends('layouts.app')

@section('content')
<div class="container">
<a href="/admin/index" class="btn btn-primary"> Go Back </a>

    <div class="row justify-content-center">
        <div class="col-md-8">
        <div class="card">
        <div class="card-header" style="font-weight:bold; font-size:50;">{{ __('Last Of Student') }}</div>



                <div class="card-body">
            @if (count($users)>0)
            <ul>
                  @foreach($users as $service)
                     <li class="list-group-item"> 
                        {{$service->userName}}
                        <div  style="float:right;" >
                        <a href="/student/{{$service->id}}/showInfo" class="btn btn-primary">Show Student Details</a>
                         <a href="/student/{{$service->id}}/studentDegree" class="btn btn-primary">Show Degres</a>
                         <a href="/student/{{$service->id}}/delete" class="btn btn-primary">Remove</a>

                         </div>
                     </li>
                  @endforeach
            </ul>    
            @endif
            </div>
            </div>
        </div>
    </div>
</div>
@endsection



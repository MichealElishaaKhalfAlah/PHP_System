@extends('layouts.app')

@section('content')

<div class="container">
    <div class="row justify-content-center">
    
  <div class="col-md-8">
            <div class="card">
                <div class="card-header"   style="font-weight:bold; font-size:50;">{{ __('Dashboard') }}</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                </div>
                <div class="card" style="float:left;">
                     <div class="card-body">
                          <a class="nav-link active btn btn-primary" aria-current="page" href="/client/create" style="font-size:20px;">Add Teacher</a>
                     </div>
               </div>
               <div class="card" style="float:right;">
                     <div class="card-body">
                         <a class="nav-link active btn btn-primary" aria-current="page" href="/student/create" style="font-size:20px;">Add Student</a>
                     </div>
                </div>
                <div class="card">
                     <div class="card-body">
                           <a class="nav-link active btn btn-primary" aria-current="page" href="/client/show" style="font-size:20px;">Show Teacher</a>
                    </div>
                </div>
                <div class="card">

                    <div class="card-body">
                        <a class="nav-link active btn btn-primary" aria-current="page" href="/student/show" style="font-size:20px;">Show Student</a>
                    </div>
               </div>

            </div>
        </div>
    </div>
</div>
@endsection

@extends('layouts.app')

@section('content')
<div class="container">
<a href="/admin/index" class="btn btn-primary"> Go Back </a>         

    <div class="row justify-content-center">
        <div class="col-md-8">
        <div class="card">
        <div class="card-header" style="font-weight:bold; font-size:50;">{{ __('List Of Client') }}</div>
                <div class="card-body">
            <form method="post" action="{{route('changeTypeOfUser')}}">  
                @csrf

                 @if (count($users)>0)
                 <ul>
                    @foreach($users as $service)
                         <li class="list-group-item">
                                <h7> {{$service->userName}} </h7>
                                 <div class="ml-auto" style="float:right;">   
                                        @if ($service->typeOfUser == 1)
                                                <input type="checkbox" id="checkAdmin" name="checkAdmin[]" value="{{$service->id}}" checked>
                                        @else
                                                <input type="checkbox" id="checkAdmin" name="checkAdmin[]" value="{{$service->id}}">
                                        @endif
                                        <h9>admin status</h9>
                                 </div>

                         </li>
                    @endforeach
                 </ul> 
                 <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ _('save changes') }}
                                </button>
                            </div>
                        </div>   
                 @endif
            </form>
            </div>
            </div>
        </div>
    </div>
</div>
@endsection



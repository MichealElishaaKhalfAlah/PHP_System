<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\students;
use Illuminate\Support\Facades\Auth;
use App\models\user;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use App\models\grades;

class StudentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $student = students::where('userId',Auth::user()->id)->first();
        //return $student;
        return view('student.index')->with('student',$student);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {        
        if (false == Auth::check()) {
            return redirect('/login');
        }
        if (Auth::user()->typeOfUser==1)
        {
            return view('student.create');    
        }
        elseif (Auth::user()->typeOfUser==2)
        {
            return view('student.create');
        }   
        else
        {
            return redirect()->route('student/index');
        }
    }
    
    public function saveStudent(Request $request)
    {
        if (false == Auth::check()) {
            return redirect('/login');
        }
          $person = new User([
            'userName' => $request['name'],
            'email' => $request['email'],
            'password' => Hash::make($request['password']),
            'typeOfUser' =>$request['typeOfUser'],
          ]);
          try { 
            $person->save();
          } 
          catch(\Illuminate\Database\QueryException $ex){ 

            return redirect('student\create')->with('alert', 'this is error data');
          } 
            $lastId=user::orderBy('id', 'desc')->first();
            $student = new students([
              'userId'=>$lastId->id,
             'address'=> $request['address'],
             'phone'=>$request['phone'],
             'academicYear'=>$request['academicYear'],
          ]);

        try { 
            $student->save();
            return redirect()->back();
          } 
          catch(\Illuminate\Database\QueryException $ex){ 
            return redirect('student\create')->with('alert', 'this is error data');
          }    
    }
  
    /**
     * Display the specified resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function show()
    { 
        if (false == Auth::check()) {
            return redirect('/login');
        }
        if (Auth::user()->typeOfUser==1)
        {
            $users = DB::table('users')->where('typeOfUser', 3)->get();
            return view('student.show')->with('users',$users);  
        }
        elseif (Auth::user()->typeOfUser==2)
        {
            $users = DB::table('users')->where('typeOfUser', 3)->get();
            return view('student.show')->with('users',$users);        
        }   
        else
        {
            return redirect()->route('student/index');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function showStudentInfo($id)
    {
        if (false == Auth::check()) {
            return redirect('/login');
        }
        $student = Students::where('userId',$id)->first();
        return view('student.showInfo')->with('student',$student);    
    }

    public function studentDegree($id)
    {
        if (false == Auth::check()) {
            return redirect('/login');
        }
    
        $student = DB::table('users as u')
        ->join('students as s','u.id','s.userId')
        ->where('u.id',$id)
        ->get(array('s.id','u.userName'));

        $grade= DB::table('grades as g')
        ->leftjoin('subjects','subjects.id','=','g.subjectId')
        ->where('g.studentId',$student[0]->id)
        ->get(array('g.grade','subjects.subjectName','subjects.id'));

        $data=array('student'=>$student,
                    'grade'=>$grade);

        return view('student.showDegree')->with($data);    
    }

    public function updateDegreer(Request $request,$id)
    {
        if (false == Auth::check()) {
            return redirect('/login');
        }

        $suId =[1,2,3];
        foreach ($suId as $oneSub)
        {
            $check = grades::where('studentId',$id)->where('subjectId',$oneSub)->first();
            if (is_numeric($request[$oneSub]))
            {
                $gradeNum=$request[$oneSub];
            }
            else
            {
                $gradeNum=0;
            }

            if ($check===null)
            {
                $grade = new grades([
                    'studentId' => $id,
                    'subjectId' => $oneSub,
                    'grade' => $gradeNum,
                  ]);
                  $grade->save();
            }
            else 
            {
             $query= DB::table('grades')->where('studentId',$id)->where('subjectId',$oneSub)->limit(1)  
             ->update(array('grade' => $gradeNum));
            }
        }
        return redirect('student/show');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {   
        if (false == Auth::check()) 
        {
            return redirect('/login');
        }
        user::where('id', $id)->delete();
        students::where('userId', $id)->delete();
        return Redirect('student/show');    
    }
}

<?php

namespace App\Http\Controllers;

use App\models\user;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use App\models\students;
use App\models\grades;
use Illuminate\Support\Facades\Auth;

class AdminController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (false == Auth::check()) {
            return redirect('/login');
        }
        if (Auth::user()->typeOfUser==1)
        {
            return view('admin.index');
        }
        elseif(Auth::user()->typeOfUser==2)
        {
            return redirect()->route('client/index');
        }
        else
        {
            return redirect()->route('student/index');
        }
    }

    public function changeTypeOfUser(Request $request)
    {
        if (false == Auth::check()) {
            return redirect('/login');
        }

       if(!empty($_POST['checkAdmin']))
       {
               foreach($_POST['checkAdmin'] as $selected)
               {
                     $query= DB::table('users')->where('id',$selected)->limit(1)  
                     ->update(array('typeOfUser' => '1'));
               }
        }
        return redirect('admin\index');
    }
}

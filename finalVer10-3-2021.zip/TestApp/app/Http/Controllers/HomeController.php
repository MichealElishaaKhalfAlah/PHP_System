<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//use App\Models\User;
//use App\Http\Controllers\Auth;
//use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;


class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */

    public function index()
    {
        if (Auth::user())
        {
          
            $typeOfUser =Auth::user()->typeOfUser;
            //return $typeOfUser;

            if ($typeOfUser == 1)
            {
                return redirect()->route('admin/index');
            }
            elseif ($typeOfUser ==2) {
                return redirect()->route('client/index');
            } 
            elseif ($typeOfUser ==3) {
                return redirect()->route('student/index');
            }
        }
    }
}

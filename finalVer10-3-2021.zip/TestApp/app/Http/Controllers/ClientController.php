<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\models\user;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;

class ClientController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('client.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (false == Auth::check()) {
            return redirect('/login');
        }
        if (Auth::user()->typeOfUser==1)
        {
            return view('client.create');
        }
        elseif (Auth::user()->typeOfUser==2)
        {
            return redirect()->route('client/index');
        }   
        else
        {
            return redirect()->route('student/index');
        }
    }

    public function saveClient(Request $request)
    {
        if (false == Auth::check()) {
            return redirect('/login');
        }
        $person = new User([
            'userName' => $request['name'],
            'email' => $request['email'],
            'password' => Hash::make($request['password']),
            'typeOfUser' =>$request['typeOfUser'],
          ]);
          try { 
            $person->save();
            return redirect('admin\index');
          } catch(\Illuminate\Database\QueryException $ex){ 
            return redirect('client\create')->with('alert', 'this is error data');
          } 
    }

    /**
     * Display the specified resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function show()
    {        
        if (false == Auth::check()) {
            return redirect('/login');
        }
        if (Auth::user()->typeOfUser==1)
        {
            $users = DB::table('users')->where('typeOfUser', 2)->get();
            return view('client.show')->with('users',$users);
        }
        elseif (Auth::user()->typeOfUser==2)
        {
            return redirect()->route('client/index');
        }   
        else
        {
            return redirect()->route('student/index');
        }
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Students extends Model
{
    protected $table = 'students';
    public $primarykey ='id';
    public $timestamps = true;    

    protected $fillable = [
        'userId',
        'address',
        'phone',
        'academicYear',
    ];
}

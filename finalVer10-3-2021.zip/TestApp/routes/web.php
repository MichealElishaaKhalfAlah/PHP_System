<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/','App\Http\Controllers\PagesController@index');

Route::get('/admin/index','App\Http\Controllers\AdminController@index' )->name('admin/index');
Route::get('/student/index','App\Http\Controllers\StudentController@index' )->name('student/index');
Route::get('/client/index','App\Http\Controllers\ClientController@index' )->name('client/index');

Route::get('/client/create','App\Http\Controllers\ClientController@create' );
Route::Post('/client/saveClient','App\Http\Controllers\ClientController@saveClient' )->name('saveClient');

Route::get('/student/create','App\Http\Controllers\StudentController@create' );
Route::Post('/student/saveStudent','App\Http\Controllers\StudentController@saveStudent' )->name('saveStudent');

Route::get('/client/show','App\Http\Controllers\ClientController@show' );
Route::get('/student/show','App\Http\Controllers\StudentController@show' )->name('showStudent');

Route::get('/student/{id}/showInfo','App\Http\Controllers\StudentController@showStudentInfo' );
Route::get('/student/{id}/studentDegree','App\Http\Controllers\StudentController@studentDegree' );

Route::get('/student/{id}/delete','App\Http\Controllers\StudentController@destroy' );

Route::post('/student/{id}/editDegree','App\Http\Controllers\StudentController@updateDegreer' )->name('editDegree');
Route::post('/admin/changeTypeOfUser','App\Http\Controllers\AdminController@changeTypeOfUser' )->name('changeTypeOfUser');

Route::resource('student','App\Http\Controllers\StudentController');
Route::resource('admin','App\Http\Controllers\AdminController');
Route::resource('client','App\Http\Controllers\ClientController');

Auth::routes();
Route::get('logout', '\App\Http\Controllers\Auth\LoginController@logout');

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');




<?php $__env->startSection('content'); ?>
<div class="container">
<a href="/admin/index" class="btn btn-primary"> Go Back </a>


           

    <div class="row justify-content-center">
        <div class="col-md-8">
        <div class="card">
        <div class="card-header" style="font-weight:bold; font-size:50;"><?php echo e(__('List Of Client')); ?></div>



                <div class="card-body">
            <form method="post" action="<?php echo e(route('changeTypeOfUser')); ?>">  
                <?php echo csrf_field(); ?>

                 <?php if(count($users)>0): ?>
                 <ul>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <li class="list-group-item">
                                <h7> <?php echo e($service->userName); ?> </h7>
                                 <div class="ml-auto" style="float:right;">   
                                        <?php if($service->typeOfUser == 1): ?>
                                                <input type="checkbox" id="checkAdmin" name="checkAdmin[]" value="<?php echo e($service->id); ?>" checked>
                                        <?php else: ?>
                                                <input type="checkbox" id="checkAdmin" name="checkAdmin[]" value="<?php echo e($service->id); ?>">
                                        <?php endif; ?>
                                        <h9>admin status</h9>
                                   <!--     <a href="/admin/deleteTeacher" class="btn btn-primary" name="removeClient[]" value="<?php echo e($service->id); ?>"> Remove</a>-->

                                 </div>

                         </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </ul> 
                 <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(_('save changes')); ?>

                                </button>
                            </div>
                        </div>   
                 <?php endif; ?>
            </form>
            </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TestApp\resources\views/client/show.blade.php ENDPATH**/ ?>
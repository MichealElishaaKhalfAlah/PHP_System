

<?php $__env->startSection('content'); ?>
    
    <h1>index page </h1>
    <p> welcome to student index then can finish the task</p>

    <?php if(count($students)>0): ?>
        <ul>
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item">
                <h5> <?php echo e($student->address); ?> </h5>
                <p> <h7> Student Id : </h7> <?php echo e($student->id); ?> </p>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

    <?php endif; ?>
<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TestApp\resources\views/pages/student/index.blade.php ENDPATH**/ ?>
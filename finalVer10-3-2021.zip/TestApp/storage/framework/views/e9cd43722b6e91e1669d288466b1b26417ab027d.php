

<?php $__env->startSection('content'); ?>

<div class="container">
<a href="/student/show" class="btn btn-primary"> Go Back </a>

    <div class="row justify-content-center">
        <div class="col-md-8">
        <div class="card">
                <div class="card-body">
            <ul>
                <li class="list-group-item"> <?php echo e($student->userId); ?> </li>
                <li class="list-group-item"> <?php echo e($student->address); ?> </li>
            </ul>    
            </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TestApp\resources\views/student/showInfo.blade.php ENDPATH**/ ?>
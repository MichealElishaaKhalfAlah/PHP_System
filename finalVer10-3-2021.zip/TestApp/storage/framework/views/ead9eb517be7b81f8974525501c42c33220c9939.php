

<?php $__env->startSection('content'); ?>

<div class="container">
<a href="/admin/showStudent" class="btn btn-primary"> Go Back </a>

    <div class="row justify-content-center">
        <div class="col-md-8">
        <form method="post" action="<?php echo e(route('editDegree', ['id' => $studentId])); ?>">  
        <?php echo csrf_field(); ?>
         
          <h1> <?php echo e($grade[0]->userName); ?> </h1>
         
            <?php if(count($grade)>0): ?>
                <ul>
                      <?php $__currentLoopData = $grade; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item">
                                  <label for="subject" class="col-md-4 col-form-label text-md-right"><?php echo e($service->subjectName); ?></label>
                                  <input id="<?php echo e($service->id); ?>" type="<?php echo e($service->id); ?>" name="<?php echo e($service->id); ?>" 
                                    value="<?php echo e($service->grade); ?>" >
                            </li>
                            
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>    
            <?php endif; ?>
                         <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(_('update')); ?>

                                </button>
                            </div>
                        </div>
            </form>


        




        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TestApp\resources\views/admin/studentDegree.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
    
    <h1>create student page </h1>
    <p> welcome to create student page then can finish the task</p>

    
<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TestApp\resources\views/pages/student/create.blade.php ENDPATH**/ ?>
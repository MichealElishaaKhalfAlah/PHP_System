

<?php $__env->startSection('content'); ?>
<div class="container">
<a href="/admin/index" class="btn btn-primary"> Go Back </a>

    <div class="row justify-content-center">
        <div class="col-md-8">
        <div class="card">
        <div class="card-header" style="font-weight:bold; font-size:50;"><?php echo e(__('Last Of Student')); ?></div>



                <div class="card-body">
            <?php if(count($users)>0): ?>
            <ul>
                  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <li class="list-group-item"> 
                        <?php echo e($service->userName); ?>

                        <div  style="float:right;" >
                        <a href="/student/<?php echo e($service->id); ?>/showInfo" class="btn btn-primary">Show Student Details</a>
                         <a href="/student/<?php echo e($service->id); ?>/studentDegree" class="btn btn-primary">Show Degres</a>
                         <a href="/student/<?php echo e($service->id); ?>/delete" class="btn btn-primary">Remove</a>

                         </div>
                     </li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>    
            <?php endif; ?>
            </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TestApp\resources\views/student/show.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>

<div class="container">
<a href="/admin/showStudent" class="btn btn-primary"> Go Back </a>

    <div class="row justify-content-center">
        <div class="col-md-8">
             
         
            <ul>
                <li class="list-group-ite  m"> <?php echo e($student->userId); ?> </li>
                <li class="list-group-item"> <?php echo e($student->address); ?> </li>


            </ul>    
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TestApp\resources\views/admin/showStudentInfo.blade.php ENDPATH**/ ?>
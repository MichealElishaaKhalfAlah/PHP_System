

<?php $__env->startSection('content'); ?>

<div class="container">
<a href="/student/show" class="btn btn-primary"> Go Back </a>

    <div class="row justify-content-center">
        <div class="col-md-8">
        <div class="card">



                <div class="card-body">
        <form method="post" action="<?php echo e(route('editDegree', ['id' => $student[0]->id])); ?>">  
        <?php echo csrf_field(); ?>
         
          <h1> <?php echo e($student[0]->userName); ?> </h1>
         
                <ul>
                            <li class="list-group-item">
                                  <label for="subject" class="col-md-4 col-form-label text-md-right">English</label>
                                  <?php $flag=0 ?>
                                  <?php $__currentLoopData = $grade; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($service->id ==1): ?>
                                           <?php $flag=1 ?>
                                            <input id="1" type="1" name="1" value="<?php echo e($service->grade); ?>" >
                                        <?php endif; ?>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  <?php if($flag==0): ?>
                                        <input id="1" type="1" name="1" value="0" >
                                  <?php endif; ?>

                            </li>
                            <li class="list-group-item">
                                  <label for="subject" class="col-md-4 col-form-label text-md-right">Math</label>
                                  <?php $flag=0 ?>
                                  <?php $__currentLoopData = $grade; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($service->id ==2): ?>
                                             <?php $flag=1 ?>
                                            <input id="2" type="2" name="2" value="<?php echo e($service->grade); ?>" >
                                        <?php endif; ?>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  <?php if($flag==0): ?>
                                        <input id="2" type="2" name="2" value="0" >
                                  <?php endif; ?>            
                            </li>
                            <li class="list-group-item">
                                  <label for="subject" class="col-md-4 col-form-label text-md-right">History</label>
                                  <?php $flag=0 ?>
                                  <?php $__currentLoopData = $grade; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($service->id ==3): ?>
                                            <?php $flag=1 ?>
                                            <input id="3" type="3" name="3" value="<?php echo e($service->grade); ?>" >
                                        <?php endif; ?>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  <?php if($flag==0): ?>
                                        <input id="3" type="3" name="3" value="0" >
                                  <?php endif; ?>
                            </li>
                </ul>    
                        <?php if(Auth::user()->typeOfUser !=3): ?>
                         <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(_('update')); ?>

                                </button>
                            </div>
                        </div>
                        <?php endif; ?>
            </form>  
            </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TestApp\resources\views/student/showDegree.blade.php ENDPATH**/ ?>
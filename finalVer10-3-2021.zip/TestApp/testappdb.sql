-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 11, 2021 at 12:30 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `testappdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `grades`
--

CREATE TABLE `grades` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `studentId` int(11) NOT NULL,
  `subjectId` int(11) NOT NULL,
  `grade` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `grades`
--

INSERT INTO `grades` (`id`, `studentId`, `subjectId`, `grade`, `created_at`, `updated_at`) VALUES
(7, 8, 1, 0, '2021-03-08 19:13:57', '2021-03-08 19:13:57'),
(8, 6, 2, 50, '2021-03-08 19:13:57', '2021-03-08 19:13:57'),
(9, 6, 3, 50, '2021-03-08 19:13:57', '2021-03-08 19:13:57'),
(10, 8, 2, 50, '2021-03-10 19:25:03', '2021-03-10 19:25:03'),
(11, 8, 3, 0, '2021-03-10 19:25:04', '2021-03-10 19:25:04'),
(12, 9, 1, 70, '2021-03-10 20:58:50', '2021-03-10 20:58:50'),
(13, 9, 2, 0, '2021-03-10 20:58:50', '2021-03-10 20:58:50'),
(14, 9, 3, 70, '2021-03-10 20:58:50', '2021-03-10 20:58:50'),
(15, 10, 1, 0, '2021-03-10 21:01:18', '2021-03-10 21:01:18'),
(16, 10, 2, 50, '2021-03-10 21:01:18', '2021-03-10 21:01:18'),
(17, 10, 3, 0, '2021-03-10 21:01:18', '2021-03-10 21:01:18');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(5, '2021_03_04_182836_create_students_table', 2),
(6, '2021_03_04_183655_type_of_user', 2),
(7, '2021_03_04_183826_create_grades_table', 2),
(8, '2021_03_04_184012_subjects', 2);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `userId` int(11) NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` int(11) NOT NULL,
  `academicYear` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `userId`, `address`, `phone`, `academicYear`, `created_at`, `updated_at`) VALUES
(8, 39, 'Shoubra Street', 4444, 4, '2021-03-09 22:52:13', '2021-03-09 22:52:13'),
(10, 42, 'Shoubra Street', 444, 4, '2021-03-10 21:00:32', '2021-03-10 21:00:32'),
(11, 46, 'Shoubra Street', 4444, 4, '2021-03-10 21:13:53', '2021-03-10 21:13:53'),
(13, 48, 'Shoubra Street', 4, 1, '2021-03-10 21:18:05', '2021-03-10 21:18:05');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `subjectName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `subjectName`, `created_at`, `updated_at`) VALUES
(1, 'English', '2021-03-04 18:44:09', NULL),
(2, 'Math', '2021-03-04 18:44:33', NULL),
(3, 'History', '2021-03-04 18:44:53', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `typeofusers`
--

CREATE TABLE `typeofusers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `typeOfUser` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `typeofusers`
--

INSERT INTO `typeofusers` (`id`, `typeOfUser`, `created_at`, `updated_at`) VALUES
(1, 'Admin', '2021-03-04 18:42:08', NULL),
(2, 'Client', '2021-03-04 18:42:55', NULL),
(3, 'Student', '2021-03-04 18:43:23', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `userName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `typeOfUser` int(11) NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `userName`, `email`, `email_verified_at`, `password`, `typeOfUser`, `remember_token`, `created_at`, `updated_at`) VALUES
(33, 'admin', 'admin@hotmail.com', NULL, '$2y$10$vnH/BJ.PzvetmDZjXCWCtOjyBEA2fKCE7aqycfibcZZ8lZxEB1iIa', 1, NULL, '2021-03-08 19:11:23', '2021-03-08 19:11:23'),
(34, 'teacherOne', 'teacherOne@gmail.com', NULL, '$2y$10$naHA/rOgUgfcCw9xTnokMepDDh4iRZnnnSyVB9qTeX3.Tqf6Q6hRO', 1, NULL, '2021-03-08 19:12:07', '2021-03-08 19:12:07'),
(35, 'teacherTwo', 'teacherTwo@hotmail.com', NULL, '$2y$10$09fgqEHmYLJrwT9TAKyyGel7fQOZol/zNtzLJidzJFFyJAFuMXoOK', 1, NULL, '2021-03-08 19:12:42', '2021-03-08 19:12:42'),
(39, 'studentOne', 'studentOne@hotmail.com', NULL, '$2y$10$hKe/880l2QHH2MTResYJOOU1ku3nKbRmSVQmd1HT.tD1Oqzww.HA6', 3, NULL, '2021-03-09 22:52:13', '2021-03-09 22:52:13'),
(40, 'TeacherThree', 'TeacherThree@gmail.com', NULL, '$2y$10$7XpUQB/jZyA/gDhN0TqAUOZfU55C5ZTyWa/CG.go47NI4OAezTJC6', 2, NULL, '2021-03-10 20:52:11', '2021-03-10 20:52:11'),
(42, 'studentTwo', 'studentTwo@gmail.com', NULL, '$2y$10$Obdh9K0cZdv/9js6pImfoOgrh5o7w/4YEZ93e4poso9VMwT4e8AHS', 3, NULL, '2021-03-10 21:00:32', '2021-03-10 21:00:32'),
(46, 'studentFour', 'studentFour@gmail.com', NULL, '$2y$10$6mcXp6E.Iq1ZUS7qTKOSPu4lcGMJ.g.w07NfcESzFz64oqwhutSTC', 3, NULL, '2021-03-10 21:13:53', '2021-03-10 21:13:53'),
(48, 'StudentFive', 'studentFive@gmail.com', NULL, '$2y$10$CYnp.NkcBrRrf2PwsDVJu.J.wjQltfMHwLM6qIhmAUvLUz4COOH4G', 3, NULL, '2021-03-10 21:18:04', '2021-03-10 21:18:04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `grades`
--
ALTER TABLE `grades`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `studentId` (`studentId`,`subjectId`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `userId` (`userId`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `typeofusers`
--
ALTER TABLE `typeofusers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `grades`
--
ALTER TABLE `grades`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `typeofusers`
--
ALTER TABLE `typeofusers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
